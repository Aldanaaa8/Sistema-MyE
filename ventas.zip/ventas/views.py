
from django.shortcuts import render, redirect, get_object_or_404
from .models import Producto, Venta, DetalleVenta,FormaPagoxVentas,Empleado,FormaPago
from .forms import VentaForm, DetalleVentaForm, FormaPagoxVentasForm
from django.forms import modelformset_factory
from django.contrib.auth.decorators import login_required
from decimal import Decimal,InvalidOperation
from django.http import JsonResponse
from django.views.decorators.http import require_POST
import json

def vista_unificada_ventas(request):
    # Obtener el código del producto enviado por GET
    codigo_producto = request.GET.get('codigo_producto')

    # Inicializar el carrito en la sesión si no existe
    if 'carrito' not in request.session:
        request.session['carrito'] = []

    # Obtener el carrito actual
    carrito = request.session['carrito']

    producto = None

    # Si se proporciona un código de producto, buscar el producto y agregarlo al carrito
    if codigo_producto:
        try:
            producto = Producto.objects.get(id=codigo_producto)

            # Verificar si el producto ya está en el carrito
            producto_en_carrito = next((item for item in carrito if item['id'] == producto.id), None)

            if producto_en_carrito:
                # Si el producto ya está en el carrito, incrementar la cantidad y actualizar el subtotal
                producto_en_carrito['cantidad'] += 1
                producto_en_carrito['subtotal'] = producto_en_carrito['precio'] * producto_en_carrito['cantidad']
            else:
                # Si el producto no está en el carrito, agregarlo
                carrito.append({
                    'id': producto.id,
                    'nombre': producto.nombre,
                    'precio': float(producto.precio),
                    'cantidad': 1,  # Puedes ajustar la cantidad de ser necesario
                    'descuento': 0,  # Puedes ajustar el descuento de ser necesario
                    'subtotal': float(producto.precio)
                })

            # Asignar el carrito actualizado a la sesión
            request.session['carrito'] = carrito
            request.session.modified = True

        except Producto.DoesNotExist:
            producto = None

    # Obtener todos los productos en el carrito
    productos_en_carrito = request.session.get('carrito', [])

    # Log para verificar el carrito
    print("Carrito actual:", productos_en_carrito)

    # Calcular el total
    total_venta = sum(item['subtotal'] for item in productos_en_carrito)

    # Intentar obtener la venta existente del usuario
    empleado = get_object_or_404(Empleado, user=request.user)
    venta = Venta.objects.filter(empleado=empleado).last()

    # Si no hay una venta en curso, crear una nueva venta
    if not venta:
        venta = Venta.objects.create(empleado=empleado)

    context = {
        'producto': producto,
        'productos_en_carrito': productos_en_carrito,
        'total_venta': total_venta,
        'venta': venta,  # Pasar el objeto 'venta' al contexto
    }

    return render(request, 'vista_unificada_ventas.html', context)


def crear_venta(request):
    if request.method == 'POST':
        # Obtener los productos del carrito de la sesión
        productos_en_carrito = request.session.get('carrito', [])

        if productos_en_carrito:
    # Obtener el empleado asociado al usuario autenticado
            empleado = get_object_or_404(Empleado, user=request.user)

    # Crear la venta
            venta = Venta.objects.create(empleado=empleado)

    # Crear los detalles de la venta
            for item in productos_en_carrito:
                producto = Producto.objects.get(id=item['id'])
                DetalleVenta.objects.create(
                    venta=venta,
                    producto=producto,
                    cantidad=item['cantidad'],
                    precio_unitario=item['precio'],
                    subtotal=item['subtotal']
                )

            # Limpiar el carrito después de la venta
            request.session['carrito'] = []
            request.session.modified = True

            # Asegúrate de redirigir con el `venta.id` a la vista de forma de pago
            print(request.session['carrito'])
            return redirect('agregar_forma_pago', venta_id=venta.id)


@login_required
def agregar_detalle_venta(request, venta_id):
    venta = get_object_or_404(Venta, id=venta_id)
    DetalleVentaFormSet = modelformset_factory(DetalleVenta, form=DetalleVentaForm, extra=1)

    if request.method == 'POST':
        formset = DetalleVentaFormSet(request.POST, queryset=DetalleVenta.objects.filter(venta=venta))
        if formset.is_valid():
            for form in formset:
                detalle_venta = form.save(commit=False)
                detalle_venta.venta = venta
                detalle_venta.save()
            venta.calcular_total()  # Actualiza el total de la venta
            return redirect('agregar_forma_pago', venta_id=venta.id)
    else:
        formset = DetalleVentaFormSet(queryset=DetalleVenta.objects.filter(venta=venta))

    return render(request, 'agregar_detalle_venta.html', {'formset': formset, 'venta': venta})



def agregar_forma_pago(request, venta_id):
    if request.method == 'POST':
        data = json.loads(request.body)
        forma_pago_id = data.get('forma_pago')
        monto = Decimal(data.get('monto', 0))

        # Aquí deberías manejar la lógica de agregar la forma de pago a la venta
        venta = Venta.objects.get(id=venta_id)
        forma_pago = FormaPago.objects.get(id=forma_pago_id)
        
        # Asignar forma de pago y monto
        FormaPagoxVentas.objects.create(venta=venta, forma_pago=forma_pago, monto=monto)

        return JsonResponse({'status': 'success'})

    return redirect('vista_unificada_ventas')


@login_required
def ver_resumen_venta(request, venta_id):
    venta = get_object_or_404(Venta, id=venta_id)
    detalles = venta.detalles.all()
    formas_pago = FormaPagoxVentas.objects.filter(venta=venta)

    return render(request, 'ver_resumen_venta.html', {
        'venta': venta,
        'detalles': detalles,
        'formas_pago': formas_pago
    })

from decimal import Decimal, InvalidOperation

def actualizar_carrito(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        producto_id = data.get('producto_id')
        cantidad = data.get('cantidad')
        descuento = data.get('descuento')

        # Obtener el carrito de la sesión
        carrito = request.session.get('carrito', [])

        for item in carrito:
            if item['id'] == int(producto_id):
                try:
                    cantidad = Decimal(cantidad)
                    descuento = Decimal(descuento)
                    # Validar que cantidad y descuento sean correctos
                    if cantidad <= 0:
                        cantidad = Decimal(item['cantidad'])
                    if not (0 <= descuento <= 100):
                        descuento = Decimal(item['descuento'])
                    # Actualizar subtotal
                    precio = Decimal(item['precio'])
                    subtotal = precio * cantidad * (1 - descuento / Decimal(100))
                    # Actualizar el carrito
                    item['cantidad'] = float(cantidad)
                    item['descuento'] = float(descuento)
                    item['subtotal'] = float(subtotal)
                except InvalidOperation:
                    continue

        # Guardar el carrito actualizado en la sesión
        request.session['carrito'] = carrito
        request.session.modified = True

        # Calcular el total de la venta
        total_venta = sum(item['subtotal'] for item in carrito)

        return JsonResponse({
            'subtotal': float(subtotal),
            'total': float(total_venta),
        })

    return JsonResponse({'success': False})
@require_POST

def eliminar_producto_carrito(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        producto_id = data.get('producto_id')
        
        # Imprimir los datos recibidos para depurar
        print("Producto a eliminar:", producto_id)
        
        # Obtener el carrito actual de la sesión
        carrito = request.session.get('carrito', [])
        
        # Imprimir el carrito antes de modificarlo
        print("Carrito antes de eliminar:", carrito)
        
        # Filtrar el producto a eliminar
        carrito = [item for item in carrito if item['id'] != int(producto_id)]
        
        # Asignar el carrito modificado a la sesión
        request.session['carrito'] = carrito
        request.session.modified = True  # Asegurar que la sesión se modifique
        
        # Imprimir el carrito después de eliminar para verificar cambios
        print("Carrito después de eliminar:", request.session['carrito'])
        
        # Calcular el nuevo total
        total = sum(item['subtotal'] for item in carrito)
        
        return JsonResponse({'success': True, 'total': total})
    
    return JsonResponse({'success': False})