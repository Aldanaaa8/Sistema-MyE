
from django.urls import path
from . import views

urlpatterns = [
    path('ventas/', views.vista_unificada_ventas, name='vista_unificada_ventas'),
    path('ventas/actualizar', views.actualizar_carrito, name='actualizar_carrito'),
    path('ventas/crear/', views.crear_venta, name='crear_venta'),
    path('ventas/<int:venta_id>/detalles/', views.agregar_detalle_venta, name='agregar_detalle_venta'),
    path('ventas/<int:venta_id>/forma_pago/', views.agregar_forma_pago, name='agregar_forma_pago'),
    path('ventas/<int:venta_id>/resumen/', views.ver_resumen_venta, name='ver_resumen_venta'),
    path('eliminar_producto_carrito/', views.eliminar_producto_carrito, name='eliminar_producto_carrito'),
]
